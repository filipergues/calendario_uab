Calendário UAb

Calendário Lectivo & Provas Presenciais da Licenciatura em Informática 2018-2019 da Universidade Aberta

Extensão criada especificamente para os alunos da Licenciatura em Informática da Universidade Aberta. 
Pode facilmente ser adaptada para incorporar outros cursos também com seleção através de uma ComboBox.
A extensão usa a API do Chrome Storage, o que permite que as opções selecionadas sejam guardadas e ainda estejam disponíveis mesmo depois de fechado o browser ou desligado o PC. 
As opções são sincronizadas e apresentadas da mesma forma em todos os PC's onde o Chrome tenha sessão iniciada.
Forked from: https://github.com/filipergues/calendario_uab

Ver3.0, Adicionado calendário lectivo. Adicionados botões dinámicos.

