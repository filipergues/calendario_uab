// file that contains the academic year information

var academic_calendar = [
	['1º semestre','1 out 2018','28 fev 2019'],
	['Provas presenciais 1º semestre época normal','28 jan 2019','28 fev 2019'],
	['2º semestre','4 mar 2019','31 jul 2019'],
	['Provas presenciais 2º semestre época normal','3 jun 2019','31 jul 2019'],
	['Provas presenciais época de recurso 1º e 2º semestre','1 jul 2019','1 set 2019'],
	['Época especial','4 nov 2019','16 dez 2019']
];
